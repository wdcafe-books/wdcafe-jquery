$(function(){

  // Rellax JS
  let rellax = new Rellax('.rellax');


  // Typeit JS
  $('.type-it').typeIt({
    strings: ['DESIGNER', 'PUBLISHER'],
    loop: true,
    breakLines: false,
    cursor: false,
    speed: 100
  });


  // Background Moving JS
  $('#section1').mousemove(function(e){

    let moveX = (e.pageX * -1 / 15);
    let moveY = (e.pageY * -1 / 15);

    // background-position: 0 0
    $('#section1').css('background-position', moveX + 'px ' + moveY + 'px')

  });


  // ScrollMagic JS
  let controller = new ScrollMagic.Controller();

  // 첫번째 장면 :  #section2
  // 1. 애니메이션 설정
  let title1 = $('#section2 h2');
  let para1 = $('#section2 p');
  let tl1 = new TimelineMax();

  tl1.from(title1, 1, { y: 20, opacity: 0 })
    .from(para1, 1, { y: 20, opacity: 0 });


  // 2. 장면 설정
  let scene1 = new ScrollMagic.Scene({
    triggerElement: "#section2",
    triggerHook: 0.5
  })
  .setTween(tl1)   
  // .addIndicators({
  //   name: 'Scene1',
  //   colorTrigger: 'green',
  //   colorStart: 'blue',
  //   colorEnd: 'blue'
  // })
  .addTo(controller);  


  // 두번째 장면 :  #section3
  // 1. 애니메이션 설정
  let c1 = $('.circle1');
  let c2 = $('.circle2');
  let c3 = $('.circle3');
  let c4 = $('.circle4');
  let tl2= new TimelineMax();

  tl2.from(c1, 1, {y: 30, opacity: 0})
    .from(c2, 1, {y: 30, opacity: 0})
    .from(c3, 1, {y: 30, opacity: 0})
    .from(c4, 1, {y: 30, opacity: 0});


  // 2. 장면 설정
  let scene2 = new ScrollMagic.Scene({
    triggerElement: "#section3",
    triggerHook: 0.5
  })
  .setTween(tl2)   
  // .addIndicators({
  //   name: 'Scene2',
  //   colorTrigger: 'green',
  //   colorStart: 'red',
  //   colorEnd: 'red'
  // })
  .addTo(controller)
  .on('start end', function(){

    // Circle Progress1
    $('.circle1').circleProgress({
      value: 0.85,
      fill: '#fc0',
      size: 130,
      animation: {
        duration: 1000
      }
    }).on('circle-animation-progress', function(event, progress) {
      $(this).find('strong').html(Math.round(85 * progress) + '<i>%</i>');
    });

    // Circle Progress2
    $('.circle2').circleProgress({
      value: 0.75,
      fill: '#fc0',
      size: 130,
      animation: {
        duration: 2000
      }
    }).on('circle-animation-progress', function(event, progress) {
      $(this).find('strong').html(Math.round(75 * progress) + '<i>%</i>');
    });

    // Circle Progress3
    $('.circle3').circleProgress({
      value: 0.60,
      fill: '#fc0',
      size: 130,
      animation: {
        duration: 3000
      }
    }).on('circle-animation-progress', function(event, progress) {
      $(this).find('strong').html(Math.round(60 * progress) + '<i>%</i>');
    });

    // Circle Progress4
    $('.circle4').circleProgress({
      value: 0.70,
      fill: '#fc0',
      size: 130,
      animation: {
        duration: 4000
      }
    }).on('circle-animation-progress', function(event, progress) {
      $(this).find('strong').html(Math.round(70 * progress) + '<i>%</i>');
    });

  });  


  // 네번째 장면 :  #section4
  // 1. 애니메이션 설정
  let title2 = $('#section4 h2');
  let para2 = $('#section4 p');
  let tl3 = new TimelineMax();

  tl3.from(title2, 1, { y: 20, opacity: 0 })
    .from(para2, 1, { y: 20, opacity: 0 });


  // 2. 장면 설정
  let scene3 = new ScrollMagic.Scene({
    triggerElement: "#section4",
    triggerHook: 0.5
  })
  .setTween(tl3)   
  // .addIndicators({
  //   name: 'Scene3',
  //   colorTrigger: 'green',
  //   colorStart: 'blue',
  //   colorEnd: 'blue'
  // })
  .addTo(controller);  


  // 다섯번째 장면 :  #section5
  // 1. 애니메이션 설정
  let pb1 = $('#section5 li:nth-child(1)');
  let pb2 = $('#section5 li:nth-child(2)');
  let pb3 = $('#section5 li:nth-child(3)');
  let pb4 = $('#section5 li:nth-child(4)');
  let tl4 = new TimelineMax();

  // tl.fromTo(대상, 지속시간, {속성}, {속성}, delay);
  tl4.fromTo(pb1, 1, {width: '1%'}, {width: '25%'}, 0.5)
    .fromTo(pb2, 1, {width: '1%'}, {width: '50%'}, 1)
    .fromTo(pb3, 1, {width: '1%'}, {width: '75%'}, 1.5)
    .fromTo(pb4, 1, {width: '1%'}, {width: '90%'}, 2);


  // 2. 장면 설정
  let scene4 = new ScrollMagic.Scene({
    triggerElement: "#section5",
    triggerHook: 0.5
  })
  .setTween(tl4)   
  // .addIndicators({
  //   name: 'Scene4',
  //   colorTrigger: 'green',
  //   colorStart: 'red',
  //   colorEnd: 'red'
  // })
  .addTo(controller);  


  // 여섯번째 장면 :  #section6
  // 1. 애니메이션 설정
  let title3 = $('#section6 h2');
  let para3 = $('#section6 p');
  let tl5 = new TimelineMax();

  tl5.from(title3, 1, { y: 20, opacity: 0 })
    .from(para3, 1, { y: 20, opacity: 0 });


  // 2. 장면 설정
  let scene5 = new ScrollMagic.Scene({
    triggerElement: "#section6",
    triggerHook: 0.5
  })
  .setTween(tl5)   
  // .addIndicators({
  //   name: 'Scene5',
  //   colorTrigger: 'green',
  //   colorStart: 'blue',
  //   colorEnd: 'blue'
  // })
  .addTo(controller);  


});