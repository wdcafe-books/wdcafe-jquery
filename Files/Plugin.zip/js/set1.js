$(function(){

  /* ScrollMagic 적용 순서 :
    1. Create the ScrollMagic Controller (and select general options)
      - 스크롤매직 컨트롤러 생성 ( 한 문서에 한번만 생성! )

    2. Create an Animation Object (and select animation options)
      - 애니메이션 오브젝트 생성 : 'GSAP'을 이용한 애니메이션 설정

    3. Create a Scene Object (and select scene options)
      - 장면(Scene) 오브젝트 생성

    4. Add our Animation Object to the Scene Object
      - 애니메이션 오브젝트를 장면(Scene) 오브젝트에 연결하기

    5. Add the Scene Object to the ScrollMagic Controller
      - 장면 오브젝트(Scene)를 스크롤매직 컨트롤러에 연결하기
  */


  // 1. Create the ScrollMagic Controller
  let controller = new ScrollMagic.Controller();

  /* ************************ 첫번째 장면 시작 ******************* */
  // 2. Create an Animation Object 
  let title1 = $('#section1 h2');
  let para1 = $('#section1 p');
  let tl1 = new TimelineMax();

  tl1.from(title1, 1, { y: 20, opacity: 0 })
    .from(para1, 1, { y: 20, opacity: 0 });


  // 3. Create a Scene Object
  let scene1 = new ScrollMagic.Scene({
    triggerElement: "#section1",
    triggerHook: 0
  })
  .setTween(tl1)   // 4. Add our Animation Object to the Scene Object
  .addIndicators({
    name: 'Scene1',
    colorTrigger: 'green',
    colorStart: 'blue',
    colorEnd: 'blue'
  })
  .addTo(controller);   // 5. Add the Scene Object to the ScrollMagic Controller

  
  /* ************************ 두번째 장면 시작 ******************* */
  let title2 = $('#section2 h2');
  let para2 = $('#section2 p');
  let tl2 = new TimelineMax();

  tl2.from(title2, 1, { y: 20, opacity: 0 })
    .from(para2, 1, { y: 20, opacity: 0 });
  
  let scene2 = new ScrollMagic.Scene({
    triggerElement : '#section2',
    triggerHook : 0.5
  })
  .setTween(tl2)
  .setClassToggle('#section2', 'bg1')   // 특정 클래스를 장면에 토글시키기
  .addIndicators({
    name: 'Scene2',
    colorTrigger: 'green',
    colorStart: 'red',
    colorEnd: 'red'
  })
  .addTo(controller);


  /* ************************ 세번째 장면 시작 ******************* */
  let title3 = $('#section3 h2');
  let para3 = $('#section3 p');
  let tl3 = new TimelineMax();

  tl3.from(title3, 1, { y: 20, opacity: 0 })
    .from(para3, 1, { y: 20, opacity: 0 });
  
  let scene3 = new ScrollMagic.Scene({
    triggerElement : '#section3',
    triggerHook : 0.5
  })
  .setTween(tl3)
  .addIndicators({
    name: 'Scene3',
    colorTrigger: 'green',
    colorStart: 'blue',
    colorEnd: 'blue'
  })
  .addTo(controller);

  /* ************************ 네번째 장면 시작 ******************* */
  let title4 = $('#section4 h2');
  let para4 = $('#section4 p');
  let tl4 = new TimelineMax();

  tl4.from(title4, 1, { y: 20, opacity: 0 })
    .from(para4, 1, { y: 20, opacity: 0 });
  
  let scene4 = new ScrollMagic.Scene({
    triggerElement : '#section4',
    triggerHook : 0.5
  })
  .setTween(tl4)
  .setClassToggle('#section4', 'bg2')   
  .addIndicators({
    name: 'Scene4',
    colorTrigger: 'green',
    colorStart: 'red',
    colorEnd: 'red'
  })
  .addTo(controller);


});